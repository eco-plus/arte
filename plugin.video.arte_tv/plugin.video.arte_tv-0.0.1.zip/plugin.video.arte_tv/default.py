from resources.lib import arte
if __name__ == '__main__':
    arte.run()
