# -*- coding: utf-8 -*-
import sys
import re
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui

from functools import reduce

from resources.lib.parser import JsonTraverseParser
try:
    from urllib.parse import urlparse #Python 3
except ImportError:
    from urlparse import urlparse #Python 2

try:
    import urllib.parse as urllib #Python 3
except ImportError:
    import urllib #Python 2

try:
    from urllib.request import Request,urlopen  #Python 3
except ImportError:
    from urllib2 import Request,urlopen  #Python 2


PY2 = sys.version_info[0] == 2
PLUGINHANDLE = int(sys.argv[1])

BASEURL = "https://www.arte.tv/"
ADDONID = "plugin.video.arte_tv"
ADDON = xbmcaddon.Addon(id=ADDONID)
ICONFOLDER = xbmc.translatePath("special://home/addons/"+ADDONID+"/")
BASEFANART = ICONFOLDER + "fanart.jpg"
BASEICON = ICONFOLDER + "icon.png"
LANGUAGE = ADDON.getSetting("language")
LANGUAGE = ["fr", "de", "en", "es", "it", "pl"][int(LANGUAGE)]
QUALFANART = ADDON.getSetting("FanartQuality")
QUALFANART = ["720x", "1920x"][int(QUALFANART)]
URLSEARCH = BASEURL + LANGUAGE + "/search/?q="
URLLIVE = 'https://artelive-lh.akamaihd.net/i/'

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0"
HEADERS = { "User-Agent" : UA }

def debuglog(a,b='',level=xbmc.LOGNOTICE):
    return xbmc.log("\t[PLUGIN ARTE] : {} {}".format(a,b), level)

def translation(lid):
    return ADDON.getLocalizedString(lid).encode("utf-8") if PY2 else ADDON.getLocalizedString(lid)

#SEARCH   
def search():
    keyboard = xbmc.Keyboard("", translation(30000))
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        searchText = urllib.quote(keyboard.getText())
        if len(searchText) > 2:
            sUrl = URLSEARCH.replace("q=","q=" + searchText + "&page=1")
            web_page(sUrl)
    return

#HOME & HOME_SUBMENU
def home_menu(sub_folder=False):
    if sub_folder:

        HtmlContent = get_url("%s%s/" % (BASEURL,LANGUAGE))

        data = JsonTraverseParser(HtmlContent)
        data_1 = data.traverse("categories")
        if data_1:
            listoflists = parse_json_data(data_1,"web_page",subcategories=True)
            addMultipleDir(listoflists)

    else:
        addDir(translation(30000), "http://arte/search", "search", "search.png")
        live_tv()
        addDir(translation(30001), "http://arte/menu", "home_menu", "menu.png")
        vid_AZ()
        addDir(translation(30011), "http://arte/allvid", "all_videos","allvid.png")
        audio_desc()
        guide_tv(menu=True)

#LIVE TV
def live_tv():
    if LANGUAGE == "fr":
       addLink(translation(30013), ("%sartelive_fr@344805/master.m3u8" % (URLLIVE)), "play_live", "live.png")
    elif LANGUAGE == "de":
       addLink(translation(30013), ("%sartelive_de@393591/master.m3u8" % (URLLIVE)), "play_live", "live.png")

#ALLVIDEOS_SUBMENU
def all_videos():
    if LANGUAGE == "fr":
       addDir("Plus vues", ("%s%s/videos/plus-vues/" % (BASEURL,LANGUAGE)), "web_page", "views.png")
       addDir("Dernière chance", ("%s%s/videos/derniere-chance/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Plus récentes", ("%s%s/videos/plus-recentes/" % (BASEURL,LANGUAGE)), "web_page", "most.png")
    elif LANGUAGE == "de":
       addDir("Meistgesehen", ("%s%s/videos/meistgesehen/" % (BASEURL,LANGUAGE)), "web_page", "views.png")
       addDir("Letzte chance", ("%s%s/videos/letzte-chance/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Neueste videos", ("%s%s/videos/neueste-videos/" % (BASEURL,LANGUAGE)), "web_page", "most.png")
    elif LANGUAGE == "en":
       addDir("Most viewed", ("%s%s/videos/most-viewed/" % (BASEURL,LANGUAGE)), "web_page", "views.png")
       addDir("Last chance", ("%s%s/videos/last-chance/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Most recent", ("%s%s/videos/most-recent/" % (BASEURL,LANGUAGE)), "web_page", "most.png")
    elif LANGUAGE == "es":
       addDir("Mas vistos", ("%s%s/videos/mas-vistos/" % (BASEURL,LANGUAGE)), "web_page", "views.png")
       addDir("Ultima oportunidad", ("%s%s/videos/ultima-oportunidad/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Los mas recientes)", ("%s%s/videos/los-mas-recientes/" % (BASEURL,LANGUAGE)), "web_page", "most.png")
    elif LANGUAGE == "it":
       addDir("Piu visti", ("%s%s/videos/piu-visti/" % (BASEURL,LANGUAGE)), "web_page", "views.png")
       addDir("Ultima opportunita", ("%s%s/videos/ultima-opportunita/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Piu recenti", ("%s%s/videos/piu-recenti/" % (BASEURL,LANGUAGE)), "web_page", "most.png")
    elif LANGUAGE == "pl":
       addDir("Najczesciej ogladane", ("%s%s/videos/najczesciej-ogladane/" % (BASEURL,LANGUAGE)), "web_page", "icon.png")
       addDir("Ostatnia szansa", ("%s%s/videos/ostatnia-szansa/" % (BASEURL,LANGUAGE)), "web_page", "chance.png")
       addDir("Najnowsze", ("%s%s/videos/najnowsze/" % (BASEURL,LANGUAGE)), "web_page", "most.png")


#A TO Z VIDEOS
def vid_AZ():
    OutputParameter = parameters_dict_as_uri("force_mode","AZ")
    if LANGUAGE == "fr":
        addDir("Émissions A-Z",("%s%s/videos/emissions/" % (BASEURL,LANGUAGE)), "web_page", "az.png",OutputParameter)
    elif LANGUAGE == "de":
       addDir("Sendungen A-Z",("%s%s/videos/sendungen/" % (BASEURL,LANGUAGE)), "web_page", "az.png", OutputParameter)
    elif LANGUAGE == "en":
       addDir("Programmes A-Z",("%s%s/programmes/" % (BASEURL,LANGUAGE)), "web_page", "az.png", OutputParameter)
    elif LANGUAGE == "es":
       addDir("Emisiones de A a Z",("%s%s/videos/emisiones/" % (BASEURL,LANGUAGE)), "web_page", "az.png", OutputParameter)
    elif LANGUAGE == "it":
       addDir("Programmi A-Z",("%s%s/programmes/" % (BASEURL,LANGUAGE)), "web_page", "az.png",OutputParameter)
    elif LANGUAGE == "pl":
       addDir("Programy od A do Z",("%s%s/programy/" % (BASEURL,LANGUAGE)), "web_page", "az.png", OutputParameter)

#AUDIO_DESCRIPTION
def audio_desc():
    if LANGUAGE == "fr":
        addDir("Audio description",("%s%s/videos/programmes-en-audiodescription/" % (BASEURL,LANGUAGE)), "web_page", "ad.png")
    elif LANGUAGE == "de":
        addDir("Audio deskription",("%s%s/videos/programme-mit-audiodeskription/" % (BASEURL,LANGUAGE)), "web_page", "ad.png")

#GUIDE_TV
def guide_tv(menu=False):

    def get_title(x):
        if LANGUAGE == "fr" :
            index = 0 
        elif LANGUAGE == 'de':
            index = 1 
        
        day = {"Monday":["Lundi","Montag"],"Tuesday":["Mardi","Dienstag"],"Wednesday":["Mercredi","Mittwoch"],
               "Thursday":["Jeudi","Donnerstag"],"Friday":["Vendredi","Freitag"],"Saturday":["Samedi","Freitag"],
               "Sunday":["Dimanche","Sonntag"]}
        
        month = {"January":["Janvier","Januar"],"February":["Février","Februar"],"March":["Mars","März"],"April":["Avril","April"],
                 "May":["Mai","Mai"],"June":["Juin","Juni"],"July":["Juillet","Juli"],"August":["Août","August"],
                 "September":["Septembre","September"],"October":["Octobre","Oktober"],"November":["Novembre","November"],
                 "December":["Décembre","Dezember"]}

        g = x.split()

        g[0] = day.get(g[0],g[0])[index]
        g[2] = month.get(g[2],g[2])[index]

        return " ".join(g)

    if menu:
        if LANGUAGE == "fr":#voir lang
            addDir("Guide TV", ("%s%s/guide/" % (BASEURL,LANGUAGE)), "guide_tv", "guide.png")
        elif LANGUAGE == "de":
            addDir("TV Programm", ("%s%s/guide/" % (BASEURL,LANGUAGE)), "guide_tv", "guide.png")
    else:
        from datetime import date, timedelta
        theday = date.today()
        start = theday - timedelta(days=3)
        dates = [start + timedelta(days=d) for d in range(7)]
        for d in dates:
            DAY = "{}".format(d)
            title = get_title(d.strftime('%A %d %B'))
            addDir(title, ("%sguide/api/emac/v3/%s/web/pages/TV_GUIDE/?day=%s" % (BASEURL,LANGUAGE,DAY)), "display_guide", "guide.png")


def display_guide(sUrl):
    Html = get_url(sUrl)
    data = JsonTraverseParser(Html)
    data_1 = data.traverse("zones.1.data")
    if data_1:
        listoflists = parse_json_data(data_1,'do_nothing')
        addMultipleDir(listoflists)

#WEB_PAGE
def web_page(sUrl):
    default_mode = parameters_string_to_dict(sys.argv[2]).get("force_mode")
    if not default_mode:
        default_mode = "get_link"

    Html = get_url(sUrl)
    data = JsonTraverseParser(Html)
    data_1 = data.traverse("pages.list.*.zones.0.data")
    if data_1:

        listoflists = parse_json_data(data_1,default_mode)
        addMultipleDir(listoflists)

        data_nextpage = data.traverse("pages.list.*.zones")
        if data_nextpage:

            url_next = extract_value(data_nextpage[0],"nextPage")
            if not url_next:
                url_next = extract_value(data_nextpage[1],"nextPage")

            if url_next:
                parsed = urlparse(url_next).hostname
                url_next = url_next.replace(parsed,"www.arte.tv/guide")

                current_page = extract_value(data_nextpage[0],"pageNumber")
                next_page = current_page + 1

                if URLSEARCH in sUrl:
                    OutputParameter = parameters_dict_as_uri("referer",sUrl.replace("&page=" + str(current_page), "&page=" + str(next_page)))
                else:
                    OutputParameter = parameters_dict_as_uri("referer",sUrl + "?page=" + str(next_page))

                addDir(translation(30012), url_next, "api_page", "next.png", OutputParameter)

#API_PAGE
def api_page(sUrl):
    referer = parameters_string_to_dict(sys.argv[2]).get("referer")
    if referer:
        referer = urllib.unquote(referer)
    else:
        referer = sUrl

    Html = get_url(sUrl)
    data = JsonTraverseParser(Html)
    data_1 = data.traverse("data")
    if data_1:

        listoflists = parse_json_data(data_1,"get_link")
        addMultipleDir(listoflists)

        data_2 = data.get_json_data()
        url_next = extract_value(data_2,"nextPage")
        if url_next:
            parsed = urlparse(url_next).hostname
            url_next = url_next.replace(parsed,"www.arte.tv/guide")

            current_page = extract_value(data_2,"pageNumber")
            next_page = current_page + 1

            new_referer = referer.replace("page=" + str(current_page), "page=" + str(next_page))

            OutputParameter = parameters_dict_as_uri("referer", new_referer)
            addDir(translation(30012), url_next, "api_page", "next.png", OutputParameter)

#
def third_page(sUrl,sub_folder=False,Html=''):

    listoflists = []
    if sUrl:
        Html = get_url(sUrl)

    data = JsonTraverseParser(Html)
    data_1 = data.traverse("pages.list.*.zones")
    if data_1:
        if sub_folder:
            for i in data_1:
                Url = extract_value(i,["link","url"])
                if Url and Url == sUrl:
                    url_next = extract_value(i,"nextPage")
                    if url_next:
                        parsed = urlparse(url_next).hostname
                        url_next = url_next.replace(parsed,"www.arte.tv/guide")

                    data_3 = extract_value(i,"data")
                    if data_3:
                        for d in data_3:
                            Url = extract_value(d,"url")
                            if not Url == sUrl:#acceuil
                                listoflists = parse_json_data(i["data"],"get_link")
                                addMultipleDir(listoflists)
                                if url_next:
                                    OutputParameter = parameters_dict_as_uri("referer", sUrl)
                                    addDir(translation(30012), url_next, "api_page", "next.png", OutputParameter)
                                break

                    else:#bad b
                        third_page(False,sub_folder=False,Html=Html)
                        break

        else:
            thumb = xbmc.getInfoLabel("ListItem.Art(thumb)")

            fanart = xbmc.getInfoLabel("ListItem.Art(fanart)")

            desc = xbmc.getInfoLabel("ListItem.plot")

            for d in data_1:
                name = extract_value(d,["code","name"])
                if name:
                    if sUrl is False:#bad banks
                        if "collection_subcollection" in name:   
                            url = extract_value(d,["link","url"])
                            title = extract_value(d,"title")
                            listoflists.append({"Url":url,"Title":"[COLOR 0xFFFD4600]" + title + "[/COLOR]","Desc":desc,"Thumb":thumb,"Fanart":fanart,"Mode":"third_page"})
                    else:
                        if "collection_videos" in name or "collection_subcollection" in name:
                            url = extract_value(d,["link","url"])
                            title = extract_value(d,"title")
                            listoflists.append({"Url":url,"Title":"[COLOR 0xFFFD4600]" + title + "[/COLOR]","Desc":desc,"Thumb":thumb,"Fanart":fanart,"Mode":"third_page"})


            addMultipleDir(listoflists)

def extract_value(dictionary,data):
    def deep_get(dictionary, keys, default=''):
        return reduce(lambda d, key: d.get(key, default) if isinstance(d, dict) else default, keys.split("."), dictionary)

    if isinstance(data, list):
        d = deep_get(dictionary,".".join(data))
    else:
        d = deep_get(dictionary,data)

    if not isinstance(d, (int, float, list)):
        if d is not None:
            d = d.encode("utf-8") if PY2 else strip_tags2(d)

    return d

def parse_json_data(data,default_mode,subcategories=False):

    listoflists = []
    for i in data:

        is_collection = extract_value(i,["kind","isCollection"])
        if is_collection and not 'AZ' in default_mode:
            mode = "third_page"
        else:
            mode = default_mode

        url = extract_value(i,"url")

        duration = extract_value(i,"duration")

        desc = extract_value(i,"description")
        if not desc:
            desc = extract_value(i,"shortDescription")

        sublabel = extract_value(i,"subtitle")

        title = extract_value(i,"title")
        if not title:
            label = extract_value(i,"label")
            title = "[COLOR 0xFFFD4600]{}[/COLOR]".format(label) if label else title
        else:
            title = title + " - [COLOR 0xFFFD4600]{}[/COLOR]".format(sublabel) if sublabel else title

        images = extract_value(i,["images","landscape","resolutions"])
        # debuglog(images)
        if images:
            for x in images:
                if QUALFANART in x["url"]:
                    fanart = x["url"]
                if "400x" in x["url"]:
                    thumb = x["url"]

        else:
            thumb = BASEICON
            fanart = BASEFANART

        if default_mode == "do_nothing":
            import datetime as dt
            import time
            bc_dates = extract_value(i,"broadcastDates")
            if bc_dates:
                bc_dates = bc_dates[0][-9:].replace("Z","")[:5]

                try: #bug python https://bugs.python.org/issue27400
                    the_time = dt.datetime.strptime(bc_dates ,"%H:%M")
                except:
                    the_time = dt.datetime(*(time.strptime(bc_dates ,"%H:%M")[0:6]))

                new_time = the_time + dt.timedelta(hours=1)
                new_time = "{:%H:%M}".format(new_time)
                title = "[COLOR 0xFFFD4600]{}[/COLOR] {}".format(new_time,title)


        listoflists.append({"Url":url,"Title":title,"Plot":desc,"Thumb":thumb,"Fanart":fanart,"Mode":mode,"Duration":duration})

        if subcategories:
            sub_categories = extract_value(i,"subcategories")
            if sub_categories:
                for cat in sub_categories:
                    url = extract_value(cat,"url")
                    desc = extract_value(cat,"description")
                    title = extract_value(cat,"label")

                    listoflists.append({"Url":url,"Title":title,"Plot":desc,"Thumb":BASEICON,"Fanart":BASEFANART,"Mode":mode})

    return listoflists

def get_url(Url):
    referer = parameters_string_to_dict(sys.argv[2]).get("referer")
    if referer:
        referer = urllib.unquote(referer)
        HEADERS.update({"Referer": referer,"Accept":"application/json, text/plain, */*","Accept-Language":"fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3"})

    req = Request(Url,headers=HEADERS)
    if not PY2:
        with urlopen(req) as rep:
            html = rep.read().decode('utf-8')
            return html
    else:
        rep = urlopen(req)
        html = rep.read()
        rep.close()
        return html

def get_link(sUrl):

    Html = get_url(sUrl)

    data = JsonTraverseParser(Html)
    data_1 = data.traverse("pages.list.*.zones.0.data.0.player.config")
    if data_1:

        HEADERS.update({"Referer": sUrl,"Accept":"application/json, text/plain, */*","Accept-Language":"fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3"})
        #view-source:https://static-cdn.arte.tv/guide/program.js
        Html = get_url('https://static-cdn.arte.tv/static/artevp/5.3.3/config/json/general.json')#change souvent

        data = JsonTraverseParser(Html)
        data_2 = data.traverse("apiplayer")
        if data_2:
            Token = extract_value(data_2,"token")
            HEADERS.update({"Authorization" : "Bearer {}".format(Token)})

            Html = get_url(data_1)

            url = []
            qua = []

            data = JsonTraverseParser(Html)
            data_3 = data.traverse("data.attributes.streams")
            if data_3:

                for d in data_3:
                    vid_url = extract_value(d,"url")
                    L = extract_value(d,"versions")[0]
                    L = extract_value(L,"label")
                    Q = extract_value(d,["mainQuality","label"])

                    L_Q = "{} {}".format(L, Q)
                    url.append(vid_url)
                    qua.append(L_Q)

                if len(url) == 1:
                    listitem = xbmcgui.ListItem(path=url[0])
                    xbmcplugin.setResolvedUrl(PLUGINHANDLE, True, listitem=listitem)

                elif len(url) > 1:
                    dialog2 = xbmcgui.Dialog()
                    ret = dialog2.select('Select Quality',qua)
                    if (ret > -1):
                        url2 = url[ret]
                        listitem = xbmcgui.ListItem(path=url2)
                        xbmcplugin.setResolvedUrl(PLUGINHANDLE, True, listitem=listitem)
                    else:
                        sys.exit()


def play_live(sUrl):
    if sUrl:
        listitem = xbmcgui.ListItem(path=sUrl)
        if '.m3u8' in sUrl:
            listitem.setMimeType("application/vnd.apple.mpegurl")

        xbmcplugin.setResolvedUrl(PLUGINHANDLE, True, listitem=listitem)
    else:
        debuglog('ARTE','No playable url found')

def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split("=")
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]

    return paramDict

def parameters_dict_as_uri(parameters_key,parameters_value):
    paramDict = {}
    if parameters_key:
        paramDict[parameters_key] = urllib.unquote(parameters_value)

    return "&{}".format(urllib.urlencode(paramDict))

def strip_tags2(text):
    clean = re.compile("<.*?>")
    return re.sub(clean, "", text)

def addLink(name, url, mode, thumb):

    thumb = ICONFOLDER + "resources/art/" + thumb

    list_item = xbmcgui.ListItem(name)
    list_item.setInfo(type="Video", infoLabels={"Title": name})
    list_item.setArt({"thumb": thumb,"fanart": BASEFANART})
    list_item.setProperty("IsPlayable", "true")
    Url = ("%s?url=%s&mode=%s" % (sys.argv[0], urllib.quote_plus(url), mode))

    xbmcplugin.addDirectoryItem(PLUGINHANDLE, Url, list_item,isFolder=False)

def addDir(name, url, mode, thumb, OutputParameter=""):

    thumb = ICONFOLDER + "resources/art/" + thumb

    params = ''
    if OutputParameter:
        params = OutputParameter

    list_item = xbmcgui.ListItem(label=name)
    list_item.setArt({"thumb": thumb ,"icon": thumb,"fanart": BASEFANART})
    list_item.setInfo(type="Video", infoLabels={"Title": name})

    Url = ("%s?url=%s&mode=%s%s" % (sys.argv[0], urllib.quote_plus(url), mode, params))

    xbmcplugin.addDirectoryItem(PLUGINHANDLE, Url, list_item, isFolder=True)


def addMultipleDir(resultlist):
    Isfolder = True
    
    listoflists = []

    for item in resultlist:

        list_item = xbmcgui.ListItem(label=item.get("Title"))
        list_item.setArt({"thumb": item.get("Thumb") ,"icon": item.get("Thumb") ,"fanart": item.get("Fanart")})
        list_item.setInfo(type="Video", infoLabels={"Title": item.get("Title"), "Plot": item.get("Plot"),"Duration":item.get("Duration")})

        if 'get_link' in item.get("Mode"):
            Isfolder = False
            list_item.setProperty("IsPlayable", "true")

        Url = ("%s?url=%s&mode=%s" % (sys.argv[0], urllib.quote_plus(item.get("Url")), item.get("Mode")))

        listoflists.append((Url, list_item, Isfolder))

    xbmcplugin.addDirectoryItems(PLUGINHANDLE, listoflists, len(listoflists))

def run():
    params = parameters_string_to_dict(sys.argv[2])
    mode = urllib.unquote_plus(params.get("mode", ""))
    url = urllib.unquote_plus(params.get("url", ""))
    content = ""

    if mode == "home_menu":
        home_menu(sub_folder=True)
        content = "addons"

    elif mode == "guide_tv":
        guide_tv()
        content = "addons"

    elif mode == "display_guide":
        display_guide(url)
        content = "addons"

    elif mode == "do_nothing":
        return

    elif mode == "all_videos":
        all_videos()
        content = "addons"

    elif mode == "web_page":
        web_page(url)
        content = "tvshows"

    elif mode == "api_page":
        api_page(url)
        content = "tvshows"

    elif mode == "AZ":
        third_page(url)
        content = "addons"

    elif mode == "get_link":
        get_link(url)

    elif mode == "third_page":
        third_page(url,sub_folder=True)
        content = "tvshows"

    elif mode == "play_live":
        play_live(url)

    elif mode == "search":
        search()
        content = "tvshows"
    else:
        first_run = ADDON.getSetting("Firstrun")
        if not first_run:
            ADDON.setSetting("Firstrun","true")
            ADDON.openSettings() 

        home_menu()
        content = "addons"

    xbmcplugin.setContent(PLUGINHANDLE, content)
    xbmcplugin.endOfDirectory(PLUGINHANDLE,cacheToDisc=True)
