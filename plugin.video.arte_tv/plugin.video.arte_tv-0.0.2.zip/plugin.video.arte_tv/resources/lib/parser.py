#-*- coding: utf-8 -*-

START = "window.__INITIAL_STATE__ = "
END = "__LOADABLE_REQUIRED_CHUNKS__"

import re
import json

import xbmc
def debuglog(a,b='',level=xbmc.LOGNOTICE):
    return xbmc.log("\t[PLUGIN ARTE] : {} {}".format(a,b), level)

class JsonTraverseParser:
    def __init__(self, raw_data):

        self.data = ''
        self.var_data = self.find_json(raw_data) if raw_data else None

        self.data = self.is_json(self.var_data) if self.var_data else None
        
    def traverse(self, path,force_list=False):

        reduced = []

        if self.data:
            reduced.append(self.data)

        if path:
            for item in path.split("."):

                list_reduced = list(reduced)

                if self.is_valid_index(item):
                    list_reduced = self.reduce_list(reduced, item)

                dict_reduced = self.flatten(reduced)
                if not list_reduced or list_reduced == reduced:
                    if item == '*':
                        dict_reduced = self.reduce_dict(dict_reduced, next(iter(list_reduced[0]))) #python 3
                    else:
                        dict_reduced = self.reduce_dict(dict_reduced, item)

                if list_reduced and list_reduced != reduced:
                    reduced = list_reduced

                elif dict_reduced and dict_reduced != self.flatten(reduced):
                    reduced = dict_reduced

                else:
                    reduced = []

        if isinstance(reduced, list) and len(reduced) == 1:
            reduced = reduced[0]

        if isinstance(reduced, list) and len(reduced) == 0:
            reduced = None

        if force_list and not isinstance(reduced, list):
            if reduced is None:
                reduced = []
            else:
                reduced = [reduced]

        return reduced

    def reduce_list(self, reduced, item):
        outputs = []

        for value in reduced:
            try:
                outputs.append(value[int(item)])
            except (ValueError, IndexError, KeyError, TypeError):
                pass

        return outputs

    def reduce_dict(self, reduced, item):
        outputs = []

        for value in reduced:
            try:
                outputs.append(value[item])
            except (KeyError, TypeError):
                pass

        return outputs

    def flatten(self, reduced):
        flattened = []
        for value_or_sublist in reduced:
            if isinstance(value_or_sublist, list):
                flattened += value_or_sublist
            else:
                flattened.append(value_or_sublist)
        return flattened

    def is_valid_index(self, string): 
        return re.match(r"^(0|[1-9][0-9]*)$", string)

    
    def find_json(self,raw_data):
        if raw_data.startswith("{") and raw_data.endswith("}"):
            return raw_data
        else:
            data = raw_data[len(START) + raw_data.find(START):raw_data.find(END)]
            if data:
                data = re.sub(';\s+</script>\s+<script id="',"",data)
                if data:
                    if data.startswith("{") and data.endswith("}"):
                        return data    
                    return False

    def is_json(self,myjson):
        try:
            json_object = json.loads(myjson)
            return json_object
        except Exception as e:
            debuglog("ERROR : {0}".format(e))
            return False

    def get_json_data(self):
        return self.data
